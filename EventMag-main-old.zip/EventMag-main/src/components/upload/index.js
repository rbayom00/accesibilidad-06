export { default as UploadMultiFile } from './UploadMultiFile';
export { default as UploadSingleFile } from './UploadSingleFile';
export { default as UploadAvatar } from './UploadAvatar';
